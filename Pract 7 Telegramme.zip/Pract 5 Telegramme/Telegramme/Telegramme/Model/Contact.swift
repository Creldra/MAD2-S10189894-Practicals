//
//  Contact.swift
//  Telegramme
//
//  Created by MAD2 on 13/11/20.
//

import Foundation

class Contact{
    var firstName:String
    var lastName:String
    var mobileNo:String
    
    init(firstname:String, lastname:String, mobileno:String){
        firstName = firstname;
        lastName = lastname;
        mobileNo = mobileno;
    }
}
