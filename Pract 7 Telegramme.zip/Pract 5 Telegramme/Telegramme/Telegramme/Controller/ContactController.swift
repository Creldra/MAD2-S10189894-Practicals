//
//  ContactController.swift
//  Telegramme
//
//  Created by MAD2 on 26/11/20.
//

import UIKit
import CoreData

class ContactController {
    func Add(newContact:Contact){
        let appDelegate = (UIApplication.shared.delegate) as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        
        let entity = NSEntityDescription.entity(forEntityName: "CDContact", in: context)!
        
        let contact = NSManagedObject(entity: entity, insertInto: context)
        contact.setValue(newContact.firstName, forKey: "firstname")
        contact.setValue(newContact.lastName, forKey: "lastname")
        contact.setValue(newContact.mobileNo, forKey: "mobileno")
        
        do{
            try context.save()
        }catch let error as NSError{
            print("Could not save. \(error), \(error.userInfo)")
        }
    }
    
    func retrieveAllContact()->[Contact]{
        var contact:[NSManagedObject] = []
        var allContact:[Contact] = []
        
        let appDelegate = (UIApplication.shared.delegate) as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "CDContact")
        do{
            contact = try context.fetch(fetchRequest)
            
            for c in contact{
                let firstname = c.value(forKeyPath: "firstname") as? String
                let lastname = c.value(forKeyPath: "lastname") as? String
                let mobileno = c.value(forKeyPath: "mobileno") as? String
                print("\(firstname!) \(lastname!), \(mobileno!)")
                
                let newContact:Contact = Contact(firstname: firstname!, lastname: lastname!, mobileno: mobileno!)
                allContact.append(newContact)
                
            }
        }catch let error as NSError{
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        return allContact
    }
    
    func updateContact(mobileno:String, newContact:Contact){
        
    }
    
    func deleteContact(mobileno:String){
        
    }
    
}
