//
//  AddContactViewController.swift
//  Telegramme
//
//  Created by MAD2 on 12/11/20.
//

import UIKit
import CoreData

class AddContactViewController: UIViewController {
    @IBOutlet weak var firstNameFld: UITextField!
    @IBOutlet weak var lastNameFld: UITextField!
    @IBOutlet weak var mobileFld: UITextField!
    
    var contact:Contact?;
    let contactController:ContactController = ContactController();
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func cancelBtn(_ sender: Any) {
        firstNameFld.text = ""
        lastNameFld.text = ""
        mobileFld.text = ""
    }
    
    @IBAction func createBtn(_ sender: Any) {
        if(firstNameFld.text! != "" && lastNameFld.text! != "" && mobileFld.text! != ""){
            
            contactController.Add(newContact: Contact(firstname: firstNameFld.text!, lastname: lastNameFld.text!, mobileno: mobileFld.text!))
            print("Contact Created")
            
        }
        
        firstNameFld.text = ""
        lastNameFld.text = ""
        mobileFld.text = ""
        
    }
    
}
